
var config = {
       container: "#collaborative-post",

       animateOnInit: true,

       node: {
           collapsable: true
       },
       animation: {
           nodeAnimation: "easeOutBounce",
           nodeSpeed: 700,
           connectorsAnimation: "easeOutBounce",
           connectorsSpeed: 500
       }
   };

var chart_config = [];
var previous_nodes = [];

function get_children(parent_id, parent_node){
    var uri = "http://172.27.1.133:8080/get";
    var data = {"parentid":parent_id};
    var c_nodes = [];

    $.getJSON(uri,data,function(result){
        var filt  = result["Posts"];
        $.each(filt, function(i, field){
            if (filt.length){
                var p = {parent: parent_node , text : { name: field['Post ID'], title : field['Text']} , image: "./res/ "+field['User ID']+".svg"}

                c_nodes.push(p)
        }});
        parent_node.text.title = result['Text'];
        parent_node.image = "./res/ "+result['User ID']+".svg";



        //Add previous nodes and the config
        var chart_config = [config,parent_node].concat(c_nodes).concat(previous_nodes);
        previous_nodes = previous_nodes.concat(chart_config);

        var tree = new Treant(chart_config);
        //POSTING
       $('#changesel').unbind().click(function (event){
            $('.node').unbind().click(function (self){
                var new_parent;
                var pid  = self['currentTarget']['textContent'][0];

                for (i =0 ; i < c_nodes.length; i ++ ){

                    if (c_nodes[i]['text']['name'] == pid){
                        new_parent = c_nodes[i];
                        break;
                    }
                }
                poster(self['currentTarget']['textContent'], $('#change').val(), $('#user').val(), new_parent);
            });

        });
        //Get NEXT
        $('.node').unbind().click(function (self){
            var pid  = self['currentTarget']['textContent'][0];
            var new_parent;

            for (i =0 ; i < c_nodes.length; i ++ ){

                if (c_nodes[i]['text']['name'] == pid){
                    console.log()
                    new_parent = c_nodes[i];
                    break;
                }
            }
            get_children(pid, new_parent);

        });





    });
}
$(document).on("pagecreate", "#mpage",function(){

    var init_node_id = 1;
    parent_node = { text : { name: init_node_id}};
    get_children(init_node_id,parent_node);




});




function poster(id, text, userid, new_parent ){
    post_url = "http://172.27.1.133:8080/create";
    var post_data = {
        "parentid" : id[0],
        "text": text,
        "userid" :userid

       };
    $.post(post_url, post_data, function(data,success){
        alert("Great Success!");

        get_children(id[0], new_parent);

    });
}

/*
//chart_config = [config, malory, lana, figgs, sterling, woodhouse, pseudo, pam, cheryl];

*/

/*$.get("uri", function(data, status){
    alert("Data: " + data + "\nStatus: " + status);
    //tree = new Treant( chart_config );

});*/
